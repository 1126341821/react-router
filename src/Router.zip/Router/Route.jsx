import React from 'react';
import './index.scss';

const arr = [
    {
        text: '申请 AR SDK',
        icon: '33'
    },
    {
        text: '准备 AR 素材',
        icon: '33'
    },
    {
        text: '生成 AR 内容',
        icon: '33'
    },
    {
        text: '应用审核',
        icon: '33'

    },
    {
        text: '应用上线',
        icon: '33'
    }
];
export default class Sevenpage extends React.Component {
    // constructor(props) {
    //   super(props);
    // }
    componentDidMount() {
    }
    componentWillUnmount() {
    }

    render() {
        return (
            <div className="seven-container">

                <div className="seven-content">
                    <h1>接入流程</h1>
                    <h5>简单5步，生成令人惊奇的增强现实应用</h5>
                    <div>
                        <ul className="step">
                            {arr.map((item, index) => {
                                const span = index < 4 ? <span className="pixelLine" /> : null;
                                return (<li key={index}>
                                    <div className="iconWrap">
                                        <span>{index + 1}</span>
                                        <i className="iconfont">&#xea1b;</i>
                                        {span}
                                    </div>
                                    <div className="textWrap">
                                        <span>{item.text}</span>
                                    </div>
                                </li>);
                            })}
                        </ul>
                    </div>

                </div>
            </div>
        );
    }
}
